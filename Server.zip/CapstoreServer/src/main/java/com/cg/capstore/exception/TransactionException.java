package com.cg.capstore.exception;

public class TransactionException extends Exception {

	public TransactionException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TransactionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
