package com.cg.capstore.exception;

public class DiscountException extends Exception {

	public DiscountException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DiscountException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
