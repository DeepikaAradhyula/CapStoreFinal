package com.cg.capstore.exception;

public class FeedbackException extends Exception {

	public FeedbackException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FeedbackException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
